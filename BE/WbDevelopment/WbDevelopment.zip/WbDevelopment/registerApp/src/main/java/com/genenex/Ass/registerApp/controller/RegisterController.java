package com.genenex.Ass.registerApp.controller;

import com.genenex.Ass.registerApp.Exception.UserAlreadyRegister;
import com.genenex.Ass.registerApp.Exception.UserNotFounds;
import com.genenex.Ass.registerApp.domain.Register;
import com.genenex.Ass.registerApp.service.RegisterService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/genex-app/v1")
public class RegisterController {

    @Autowired
    private RegisterService registerService;
   // http://localhost:8880/genex-app/v1/register
    @PostMapping("/register")
    public ResponseEntity<?> register(@RequestBody Register register) throws UserAlreadyRegister{
        try{
            return  new ResponseEntity<>(registerService.register(register),HttpStatus.OK);
        } catch ( UserAlreadyRegister ex){
         throw new UserAlreadyRegister();
        }

    }

    @PostMapping("/login")
    public ResponseEntity<?>login(@RequestBody Register register) throws UserNotFounds{
        try {
            return new ResponseEntity<>(registerService.login(register.getEmail(), register.getPassword()),HttpStatus.OK);
        } catch (UserNotFounds ex){
            throw new UserNotFounds();
        }
    }
}
